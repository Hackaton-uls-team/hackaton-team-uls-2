<?php
require_once "contenido/header.php";

session_start();

    if ($_GET["action"] == "index") {
      # code...
      require "contenido/principal.php";
    }
    elseif ($_GET["action"] == "about") {
      # code...
      require "contenido/about.php";
    }
    elseif ($_GET["action"] == "post") {
      # code...
      require "contenido/post.php";
    }
    elseif ($_GET["action"] == "contact") {
      # code...
      require "contenido/contact.php";
    }
    elseif ($_GET["action"] == "") {
      # code...
      require "contenido/principal.php";
    }
    elseif ($_GET["action"] == "login") {
      # code...
      require "contenido/login.php";
    }
    elseif ($_GET["action"] == "registrar") {
      # code...
      require "contenido/registrar.php";
    }
    elseif ($_GET["action"] == "crearpost") {
      # code...
      require "contenido/crearpost.php";
    }
    elseif ($_GET["action"] == "post") {
      # code...
      require "contenido/post.php";
    }
  


     ?>

    <hr>

    <!-- Footer -->
    <?php

    require "contenido/footer.php";
     ?>
