
<div class="container">
  <div class="row">
    <div class="col-lg-8 col-md-10 mx-auto">
      <?php
      $_SESSION['usuario']="admin";
      $mysqli = new mysqli('127.0.0.1', 'dcc', 'dcc', 'observatorio');


      // ¡Oh, no! Existe un error 'connect_errno', fallando así el intento de conexión
      if ($mysqli->connect_errno) {
          // La conexión falló. ¿Que vamos a hacer?
          // Se podría contactar con uno mismo (¿email?), registrar el error, mostrar una bonita página, etc.
          // No se debe revelar información delicada

          // Probemos esto:
          echo "Lo sentimos, este sitio web está experimentando problemas.";

          // Algo que no se debería de hacer en un sitio público, aunque este ejemplo lo mostrará
          // de todas formas, es imprimir información relacionada con errores de MySQL -- se podría registrar
          echo "Error: Fallo al conectarse a MySQL debido a: \n";
          echo "Errno: " . $mysqli->connect_errno . "\n";
          echo "Error: " . $mysqli->connect_error . "\n";

          // Podría ser conveniente mostrar algo interesante, aunque nosotros simplemente saldremos
          exit;
      }
      $query = "SELECT * FROM post ORDER BY id DESC";
      $resultado = $mysqli->query($query);

    while($row = mysqli_fetch_array($resultado)){
        # code...
  $id= $row['id'];
  $_SESSION['id'] = $id;
        ?>
        <div class="post-preview">
          <a href="index.php?action=post">
            <h2 class="post-title">
              <?php

              echo $row['titulo']; ?>
            </h2>
            <h3 class="post-subtitle">
              <?php echo $row['descripcion']; ?>
            </h3>
          </a>
          <p class="post-meta">Posted by
            <a href="#">Start Bootstrap</a>
            on September 24, 2017</p>
        </div>
        <hr>
        <?php
      }
      $mysqli->close();

       ?>

      <!-- Pager -->
      <div class="clearfix">
        <a class="btn btn-primary float-right" href="#">Older Posts &rarr;</a>
      </div>
    </div>
  </div>
</div>
