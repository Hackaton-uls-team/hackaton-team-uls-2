<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="index.html" method="post">
      <input type="text" name="nombre" id="nombre" value="">
    </form>
  </body>
</html>
