<?php

echo $_GET['nombre'];

 ?>
