

    <!-- Main Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <h2>  Capítulo II</h2>
          <p>

            <P><strong>Entes obligados y titulares</strong></p>
          <p> <strong> Entes obligados</strong></p>
          <p>  Art. 7. Están obligados al cumplimiento de esta ley los órganos del Estado, sus dependencias, las instituciones autónomas, las municipalidades o cualquier otra entidad u organismo que administre recursos públicos, bienes del Estado o ejecute actos de la administración pública en general. </p>
            <P>Se incluye dentro de los recursos públicos aquellos fondos provenientes de Convenios o Tratados que celebre el Estado con otros Estados o con Organismos Internacionales, a menos que el Convenio o Tratado determine otro régimen de acceso a la información.</p>
            <p>También están obligadas por esta ley las sociedades de economía mixta y las personas naturales o jurídicas que manejen recursos o información pública o ejecuten actos de la función estatal, nacional o local tales como las contrataciones públicas, concesiones de obras o servicios públicos. El ámbito de la obligación de estos entes se limita a permitir el acceso a la información concerniente a la administración de los fondos o información pública otorgados y a la función pública conferida, en su caso.</p>
            <p>En consecuencia, todos los servidores públicos, dentro o fuera del territorio de la República, y las personas que laboren en las entidades mencionadas en este artículo, están obligados al cumplimiento de la presente ley.
            </p>
            <p><strong>Inclusión de entes obligados regulados en leyes orgánicas o especiales</strong></p>
          <p>  Art. 8. Se entienden obligadas por esta ley las instituciones públicas cuyas leyes orgánicas o especiales estipulen que para adquirir obligaciones mediante otra ley deben ser nombradas expresamente, tales como la Comisión Ejecutiva Hidroeléctrica del Río Lempa y el Instituto Salvadoreño del Seguro Social.
          </p>
            <p><strong>Titulares de los derechos</strong></P>
            <p>Art. 9. El ejercicio de los derechos establecidos en esta ley corresponde a toda persona, por sí o por medio de su representante, sin necesidad de acreditar interés legítimo o derecho precedente.
          </p>
        </div>
      </div>
    </div>
